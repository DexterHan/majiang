
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameState, MAX_HAND_SIZE, TileData, TileType } from './types';
import { MahjongTile } from './components/MahjongTile';
import { motion, AnimatePresence } from 'framer-motion';
import * as Sound from './utils/audio';

// --- Constants ---
const TILE_W = 44; 
const TILE_H = 60; 
const LAYER_DELAY = 0.05; 
const VERSION = "v2.9.17"; // Feature: UI Position Adjustment

// --- Icons (Redesigned & Resized to 24px) ---

// Icon: Classic Refresh/Sync (Shuffle) - Standard 2-arrow cycle
const ShuffleIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
    <path d="M21 3v5h-5" />
    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
    <path d="M8 21H3v-5" />
  </svg>
);

// Icon: Counter-clockwise Arrow (Undo)
const UndoIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 14 4 9l5-5" />
    <path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11" />
  </svg>
);

// --- Logic Helpers ---
const isTileBlocked = (tile: TileData, allTiles: TileData[]): boolean => {
  const higherTiles = allTiles.filter(t => t.zIndex > tile.zIndex);
  if (higherTiles.length === 0) return false;

  const hw = TILE_W / 2;
  const hh = TILE_H / 2;
  const p = 4; 

  const points = [
    { x: tile.x - hw + p, y: tile.y - hh + p },
    { x: tile.x + hw - p, y: tile.y - hh + p },
    { x: tile.x - hw + p, y: tile.y + hh - p },
    { x: tile.x + hw - p, y: tile.y + hh - p },
    { x: tile.x,          y: tile.y          }
  ];

  let blockedPoints = 0;

  for (const point of points) {
    const isPointCovered = higherTiles.some(blocker => {
       const bLeft = blocker.x - hw;
       const bRight = blocker.x + hw;
       const bTop = blocker.y - hh;
       const bBottom = blocker.y + hh;
       return point.x > bLeft && point.x < bRight && 
              point.y > bTop && point.y < bBottom;
    });

    if (isPointCovered) blockedPoints++;
  }
  return blockedPoints >= 3;
};

const assignStackingDelays = (tiles: TileData[]): TileData[] => {
    return tiles.map(t => ({
        ...t,
        delay: (t.zIndex * 0.05) + (t.y / 1000)
    }));
};

// --- Level Generation Algorithms ---
const generateTutorialLevel = (): TileData[] => {
    const tiles: TileData[] = [];
    const rows = 3;
    const cols = 3;
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
             tiles.push({
                 id: `t1-${r}-${c}`,
                 type: TileType.DOT_1, 
                 zIndex: 0,
                 x: (c - 1) * TILE_W,
                 y: (r - 1) * TILE_H,
                 rotation: 0
             });
        }
    }
    return tiles; 
};

const generateChallengeLevel = (): TileData[] => {
    let potentialSlots: {x: number, y: number, z: number, rotation: number}[] = [];
    let zCounter = 0;

    const scatterCount = 12;
    for (let i = 0; i < scatterCount; i++) {
        potentialSlots.push({
            x: (Math.random() - 0.5) * 320, 
            y: (Math.random() - 0.5) * 400, 
            z: zCounter++, 
            rotation: (Math.random() - 0.5) * 60 
        });
    }

    const coreCount = 81; 
    const minSpiralRadius = 60; 
    const maxSpiralRadius = 125; 
    for (let i = 0; i < coreCount; i++) {
        const normalizedIndex = i / (coreCount - 1);
        const angle = 0.55 * i; 
        const radius = minSpiralRadius + (normalizedIndex * (maxSpiralRadius - minSpiralRadius));
        potentialSlots.push({
            x: Math.cos(angle) * radius,
            y: Math.sin(angle) * radius,
            z: zCounter++, 
            rotation: (Math.random() - 0.5) * 8 
        });
    }

    const stackHeight = 6; 
    const stackOffsetStep = 3; 
    const anchors = [
        { x: -75, y: -185 }, { x: -130, y: -185 },
        { x: 75,  y: -185 }, { x: 130, y: -185 },
        { x: -75, y: 185 },  { x: -130, y: 185 },
        { x: 75,  y: 185 },  { x: 130, y: 185 }
    ];

    const centerShift = ((stackHeight - 1) * stackOffsetStep) / 2;
    anchors.forEach(anchor => {
        const topAnchorX = anchor.x + centerShift;
        const topAnchorY = anchor.y - centerShift;
        for (let k = 0; k < stackHeight; k++) {
            const depth = (stackHeight - 1) - k; 
            potentialSlots.push({
                x: topAnchorX - (depth * stackOffsetStep), 
                y: topAnchorY + (depth * stackOffsetStep), 
                z: zCounter++, 
                rotation: 0 
            });
        }
    });

    potentialSlots.sort((a, b) => b.z - a.z);
    
    const remainder = potentialSlots.length % 3;
    const finalSlots = potentialSlots.slice(remainder);

    return finalSlots.map((slot, i) => ({
        id: `t2-${i}`,
        type: TileType.DOT_1,
        zIndex: slot.z,
        x: slot.x,
        y: slot.y,
        rotation: slot.rotation
    }));
};

const assignTypes = (tiles: TileData[]): TileData[] => {
    const allTypes = Object.values(TileType);
    const count = tiles.length;
    
    if (count % 3 !== 0) console.error("Tile count not divisible by 3", count);

    const numSets = Math.floor(count / 3);
    let typePool: TileType[] = [];
    
    for (let i = 0; i < numSets; i++) {
        const type = allTypes[Math.floor(Math.random() * allTypes.length)];
        typePool.push(type, type, type);
    }

    for (let i = typePool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [typePool[i], typePool[j]] = [typePool[j], typePool[i]];
    }

    return tiles.map((t, i) => ({
        ...t,
        type: typePool[i]
    }));
};

// --- Main Component ---

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [level, setLevel] = useState(1);
  const [tiles, setTiles] = useState<TileData[]>([]);
  const [hand, setHand] = useState<TileData[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLevelReady, setIsLevelReady] = useState(false);
  
  // New State: Track matched tiles for animation before removal
  const [matchedIds, setMatchedIds] = useState<string[]>([]);

  // Refs
  const tilesRef = useRef(tiles);
  const handRef = useRef(hand);
  const isProcessingRef = useRef(isProcessing);

  useEffect(() => {
    tilesRef.current = tiles;
    handRef.current = hand;
    isProcessingRef.current = isProcessing;
  }, [tiles, hand, isProcessing]);

  // --- Core Game Loop ---
  useEffect(() => {
    if (gameState === GameState.PLAYING) {
        Sound.initAudio();
        
        let rawLayout: TileData[] = [];
        if (level === 1) {
            rawLayout = generateTutorialLevel();
        } else {
            rawLayout = generateChallengeLevel();
        }

        const typedTiles = assignTypes(rawLayout);
        const delayedTiles = assignStackingDelays(typedTiles);
        
        const processedTiles = delayedTiles.map(t => ({
            ...t,
            isBlocked: isTileBlocked(t, delayedTiles)
        }));
        
        setTiles(processedTiles);
        setHand([]);
        setMatchedIds([]);
        setIsProcessing(false);
        setIsLevelReady(true);
    }
  }, [gameState, level]);

  // Win/Loss
  useEffect(() => {
    if (gameState !== GameState.PLAYING || !isLevelReady) return;

    if (tiles.length === 0 && hand.length === 0) {
       Sound.playWin();
       setTimeout(() => {
           if (level === 1) {
               setIsLevelReady(false);
               setLevel(2);
           } else {
               setGameState(GameState.WON);
           }
       }, 1000);
    } else if (hand.length >= MAX_HAND_SIZE) {
       const types = hand.map(t => t.type);
       const hasMatch = types.some(t => types.filter(x => x === t).length >= 3);
       
       // Only lose if we are not currently processing a potential match animation
       if (!hasMatch && !isProcessing && matchedIds.length === 0) {
           Sound.playLose();
           setGameState(GameState.LOST);
       }
    }
  }, [tiles, hand, gameState, level, isProcessing, isLevelReady, matchedIds]);

  // --- Interactions ---

  const handleTileClick = useCallback((clickedTile: TileData) => {
    if (isProcessingRef.current) return;
    if (handRef.current.length >= MAX_HAND_SIZE) return;
    if (!tilesRef.current.some(t => t.id === clickedTile.id)) return;
    
    isProcessingRef.current = true;
    setIsProcessing(true); 

    Sound.playClick();

    // 1. Move Board -> Hand
    setTiles(prev => {
        const remaining = prev.filter(t => t.id !== clickedTile.id);
        return remaining.map(t => ({
            ...t,
            isBlocked: isTileBlocked(t, remaining)
        }));
    });

    setHand(prev => {
        const handTile = { ...clickedTile, delay: 0, isBlocked: false }; 
        const newHand = [...prev, handTile];
        const typeOrder = Object.values(TileType);
        newHand.sort((a, b) => typeOrder.indexOf(a.type) - typeOrder.indexOf(b.type));
        return newHand;
    });

    // 2. Check Matches with Animation Delay
    // Reduced from 350ms to 250ms for snappier feel
    setTimeout(() => {
        // Use Ref to check the hand status *after* the tile arrived
        const currentHand = handRef.current;
        const counts: Record<string, number> = {};
        currentHand.forEach(t => counts[t.type] = (counts[t.type] || 0) + 1);
        
        const matchType = Object.keys(counts).find(type => counts[type] >= 3);
        
        if (matchType) {
            // MATCH FOUND!
            
            // Identify the 3 matched tiles
            const matchedTiles = currentHand.filter(t => t.type === matchType).slice(0, 3);
            const ids = matchedTiles.map(t => t.id);

            // Trigger Animation Phase
            setMatchedIds(ids);
            Sound.playMatch();

            // Reduced from 550ms to 250ms for instant "pop" effect
            setTimeout(() => {
                setHand(prev => prev.filter(t => !ids.includes(t.id)));
                setMatchedIds([]);
                setIsProcessing(false);
                isProcessingRef.current = false;
            }, 250); 
        } else {
            // No Match - Unlock immediately
            setIsProcessing(false);
            isProcessingRef.current = false;
        }
    }, 250); // Initial wait for tile to land in hand

  }, []);

  // --- Power Ups ---

  const handleShuffle = () => {
      Sound.playClick();
      setTiles(prev => {
          const positions = prev.map(t => ({x: t.x, y: t.y, zIndex: t.zIndex, id: t.id}));
          const types = prev.map(t => t.type);
          types.sort(() => Math.random() - 0.5);
          return positions.map((pos, i) => ({
              ...pos,
              type: types[i],
              rotation: 0,
              isBlocked: false 
          })).map((t, _, arr) => ({
              ...t,
              isBlocked: isTileBlocked(t, arr)
          }));
      });
  };

  const handleUndo = () => {
      if (hand.length === 0) return;
      Sound.playClick();
      const lastTile = hand[hand.length - 1];
      const newHand = hand.slice(0, -1);
      setHand(newHand);
      setTiles(prev => {
          const maxZ = Math.max(...prev.map(t => t.zIndex), 0);
          const returned = { ...lastTile, zIndex: maxZ + 1, isBlocked: false };
          const combined = [...prev, returned];
          return combined.map(t => ({...t, isBlocked: isTileBlocked(t, combined)}));
      });
  };

  return (
    <div className="relative w-full h-screen bg-neutral-900 overflow-hidden flex flex-col items-center select-none">
      
      {/* Background */}
      <div className="absolute inset-0 bg-[#0d4528] opacity-80 pointer-events-none"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#000000_100%)] opacity-60 pointer-events-none"></div>

      {/* Header */}
      <div className="relative z-10 w-full max-w-lg px-6 py-4 flex justify-between items-center text-[#ede9d6]">
        <div className="flex flex-col">
            <h1 className="text-xl font-bold tracking-widest uppercase">Mahjong Match</h1>
            <span className="text-xs opacity-70">
                {level === 1 ? "Tutorial" : "Challenge"} &bull; Tiles: {tiles.length}
            </span>
        </div>
        <button 
           onClick={() => { 
               setIsLevelReady(false);
               setLevel(1); 
               setGameState(GameState.START); 
           }}
           className="p-2 hover:bg-white/10 rounded-full transition-colors"
        >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                <path d="M3 3v5h5" />
            </svg>
        </button>
      </div>

      {/* Game Area */}
      <div className="flex-1 w-full max-w-2xl relative flex items-center justify-center">
        {gameState === GameState.START && (
            <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="z-50 text-center"
            >
                <h1 className="text-5xl font-black text-[#ede9d6] mb-4 drop-shadow-lg" style={{ fontFamily: '"Noto Serif SC", serif' }}>
                    麻将合成
                </h1>
                <p className="text-white/40 mb-8 text-xs font-mono tracking-widest">{VERSION}</p>
                <button 
                    onClick={() => {
                        setIsLevelReady(false);
                        setLevel(1);
                        setGameState(GameState.PLAYING);
                    }}
                    className="px-8 py-3 bg-[#b91c1c] text-[#fdfbf7] text-xl font-bold rounded-full shadow-xl hover:bg-[#991b1b] transition-transform active:scale-95"
                >
                    开始游戏
                </button>
            </motion.div>
        )}

        {gameState === GameState.WON && (
             <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="z-50 text-center bg-black/80 p-8 rounded-2xl backdrop-blur-sm border border-[#ede9d6]/20"
         >
             <h2 className="text-4xl font-bold text-[#ede9d6] mb-4">YOU BEAT THE GAME!</h2>
             <p className="text-white/70 mb-8">You are a legend.</p>
             <button 
                 onClick={() => { 
                     setIsLevelReady(false);
                     setLevel(1); 
                     setGameState(GameState.START); 
                 }}
                 className="px-6 py-2 bg-[#15803d] text-white rounded-lg font-bold hover:bg-[#166534]"
             >
                 Restart
             </button>
         </motion.div>
        )}

        {gameState === GameState.LOST && (
             <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="z-50 text-center bg-black/80 p-8 rounded-2xl backdrop-blur-sm border border-red-500/20"
         >
             <h2 className="text-4xl font-bold text-red-500 mb-4">Out of Moves</h2>
             <button 
                 onClick={() => { 
                     setIsLevelReady(false);
                     setGameState(GameState.PLAYING);
                 }}
                 className="px-6 py-2 bg-white/10 text-white rounded-lg font-bold hover:bg-white/20"
             >
                 Try Again
             </button>
         </motion.div>
        )}

        {gameState === GameState.PLAYING && (
            <div className="relative w-full h-full">
                {tiles.map(tile => (
                    <MahjongTile 
                        key={tile.id} 
                        tile={tile} 
                        onClick={handleTileClick} 
                    />
                ))}
            </div>
        )}
      </div>

      {/* Hand Dock */}
      <div className="w-full max-w-xl pb-4 px-4 flex flex-col gap-2 z-[100]">
            {/* Power-up Buttons (Jade Tokens) */}
            <div className="flex justify-center gap-16">
                <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={handleUndo} 
                    className="w-12 h-12 rounded-full bg-[#063326] border border-[#6ee7b7] flex items-center justify-center text-[#6ee7b7] shadow-[0_2px_8px_rgba(0,0,0,0.4)] hover:bg-[#0a4533] hover:brightness-110 active:shadow-inner transition-all"
                    title="Undo"
                >
                    <UndoIcon />
                </motion.button>
                
                <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={handleShuffle} 
                    className="w-12 h-12 rounded-full bg-[#063326] border border-[#6ee7b7] flex items-center justify-center text-[#6ee7b7] shadow-[0_2px_8px_rgba(0,0,0,0.4)] hover:bg-[#0a4533] hover:brightness-110 active:shadow-inner transition-all"
                    title="Shuffle"
                >
                    <ShuffleIcon />
                </motion.button>
            </div>

            <div className="h-20 sm:h-24 bg-[#0a291d] rounded-2xl border-2 border-[#153e30] flex items-center justify-center shadow-inner relative overflow-visible">
                <div className="relative flex items-center gap-1">
                    <div className="flex gap-1 opacity-20 pointer-events-none">
                        {Array.from({length: 7}).map((_, i) => (
                            <div key={i} className="w-10 h-14 sm:w-[3.2rem] sm:h-[4.2rem] border border-[#ede9d6] rounded-md"></div>
                        ))}
                    </div>
                    <div className="absolute inset-0 flex items-center justify-start gap-1">
                        <AnimatePresence mode='popLayout'>
                            {hand.map((tile) => (
                                <MahjongTile 
                                    key={tile.id} 
                                    tile={tile} 
                                    onClick={() => {}} 
                                    isInHand={true}
                                    isMatching={matchedIds.includes(tile.id)}
                                />
                            ))}
                        </AnimatePresence>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default App;
