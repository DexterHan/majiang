
let ctx: AudioContext | null = null;

const getCtx = () => {
    if (!ctx) {
        // Fallback for Safari/older browsers
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        ctx = new AudioContextClass();
    }
    return ctx;
};

export const initAudio = () => {
    const context = getCtx();
    if (context.state === 'suspended') {
        context.resume().catch(e => console.error("Audio resume failed", e));
    }
};

const createOsc = (freq: number, type: OscillatorType, startTime: number, duration: number, vol: number = 0.1) => {
    const context = getCtx();
    const osc = context.createOscillator();
    const gain = context.createGain();
    
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);
    
    // Envelope to avoid clicking and create smooth fade
    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(vol, startTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    
    osc.connect(gain);
    gain.connect(context.destination);
    
    osc.start(startTime);
    osc.stop(startTime + duration);
};

export const playClick = () => {
    const context = getCtx();
    const t = context.currentTime;
    
    // Crisp, short high-pitched click (Wood-like)
    const osc = context.createOscillator();
    const gain = context.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(1200, t + 0.05); // Pitch up slightly
    
    gain.gain.setValueAtTime(0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    
    osc.connect(gain);
    gain.connect(context.destination);
    
    osc.start(t);
    osc.stop(t + 0.05);
};

export const playMatch = () => {
    const context = getCtx();
    const t = context.currentTime;
    // Soft C Major Arpeggio (C5, E5, G5)
    createOsc(523.25, 'sine', t, 0.3, 0.15);
    createOsc(659.25, 'sine', t + 0.08, 0.3, 0.15);
    createOsc(783.99, 'sine', t + 0.16, 0.4, 0.15);
};

export const playWin = () => {
    const context = getCtx();
    const t = context.currentTime;
    // Ascending Scale / Flourish
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C E G C
    notes.forEach((freq, i) => {
        createOsc(freq, 'triangle', t + (i * 0.1), 0.4, 0.1);
    });
};

export const playLose = () => {
    const context = getCtx();
    const t = context.currentTime;
    // Descending discordant tones
    createOsc(300, 'sawtooth', t, 0.4, 0.05);
    createOsc(240, 'sawtooth', t + 0.2, 0.6, 0.05);
};
