
export enum TileType {
  DOT_1 = 'DOT_1',
  DOT_2 = 'DOT_2',
  DOT_3 = 'DOT_3',
  DOT_4 = 'DOT_4',
  DOT_5 = 'DOT_5',
  DOT_6 = 'DOT_6',
  CHAR_1 = 'CHAR_1',
  CHAR_2 = 'CHAR_2',
  CHAR_3 = 'CHAR_3',
  // Removed CHAR_4, CHAR_5, CHAR_6 to reduce difficulty
  RED_DRAGON = 'RED_DRAGON', // Zhong
  GREEN_DRAGON = 'GREEN_DRAGON', // Fa
  WHITE_DRAGON = 'WHITE_DRAGON', // Bai
}

export interface TileData {
  id: string;
  type: TileType;
  zIndex: number;
  x: number; // Pixel offset from center
  y: number; // Pixel offset from center
  rotation: number;
  isBlocked?: boolean; // Calculated property for gameplay
  delay?: number; // Calculated entrance animation delay
}

export enum GameState {
  START = 'START',
  PLAYING = 'PLAYING',
  WON = 'WON',
  LOST = 'LOST',
}

export const MAX_HAND_SIZE = 7;
