
import React from 'react';
import { TileType } from '../types';

interface TileContentProps {
  type: TileType;
  className?: string;
}

// --- TRADITIONAL PALETTE ---
const PIGMENT = {
    RED: "#c23a30",   // Cinnabar (朱砂)
    GREEN: "#0f766e", // Teal/Jade (翡翠)
    BLUE: "#1e3a8a",  // Indigo (靛青)
    BLACK: "#171717"  // Ink (墨)
};

// --- OPTIMIZED ASSETS ---

// Reference style: Bold Outer Ring, Clear White Gap, Solid Inner Dot, White Pinhole
const ConcentricPip = ({ cx, cy, color, r = 16 }: { cx: number; cy: number; color: string; r?: number }) => (
  <g>
    {/* Outer Ring - Thicker for classic "Tong" look */}
    <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={r * 0.35} />
    {/* Inner Circle - Sized to create a distinct white gap */}
    <circle cx={cx} cy={cy} r={r * 0.45} fill={color} />
    {/* Center Pinhole */}
    <circle cx={cx} cy={cy} r={r * 0.15} fill="#faf9f6" />
  </g>
);

// Ornate One Dot (The "Pancake")
const OrnateOneDot = () => (
  <g>
     <circle cx="50" cy="50" r="36" fill="none" stroke={PIGMENT.BLUE} strokeWidth="8" />
     <circle cx="50" cy="50" r="36" fill="none" stroke="#faf9f6" strokeWidth="2" strokeDasharray="4 6" opacity="0.9" />
     <circle cx="50" cy="50" r="25" fill="none" stroke={PIGMENT.GREEN} strokeWidth="6" />
     <circle cx="50" cy="50" r="16" fill={PIGMENT.RED} />
     <circle cx="50" cy="50" r="6" fill="none" stroke="#faf9f6" strokeWidth="1.5" />
     <circle cx="50" cy="50" r="2.5" fill="#faf9f6" />
     {[0, 60, 120, 180, 240, 300].map((deg, i) => {
         const rad = deg * Math.PI / 180;
         return <circle key={i} cx={50 + 25 * Math.cos(rad)} cy={50 + 25 * Math.sin(rad)} r="2" fill="#faf9f6" />
     })}
  </g>
);

// Characters (Wan)
const CharText = ({ num }: { num: string }) => (
  <div className="flex flex-col items-center justify-center h-full w-full gap-0 translate-y-[-1px]">
    <span className="text-2xl font-black leading-none text-[#171717]" style={{ fontFamily: '"Noto Serif SC", serif' }}>{num}</span>
    <span className="text-3xl font-black leading-none text-[#c23a30] mt-[-2px]" style={{ fontFamily: '"Noto Serif SC", serif' }}>萬</span>
  </div>
);

export const TileContent: React.FC<TileContentProps> = ({ type, className = '' }) => {
  
  switch (type) {
    case TileType.DOT_1:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1.5 ${className}`}>
          <OrnateOneDot />
        </svg>
      );
    case TileType.DOT_2:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
           {/* Ref Image: Typically Top Green, Bottom Blue for 2 Dot (pairing with 4) */}
           <ConcentricPip cx={50} cy={24} color={PIGMENT.GREEN} r={19} />
           <ConcentricPip cx={50} cy={76} color={PIGMENT.BLUE} r={19} />
        </svg>
      );
    case TileType.DOT_3:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
           <ConcentricPip cx={22} cy={22} color={PIGMENT.BLUE} r={17} />
           <ConcentricPip cx={50} cy={50} color={PIGMENT.RED} r={17} />
           <ConcentricPip cx={78} cy={78} color={PIGMENT.GREEN} r={17} />
        </svg>
      );
    case TileType.DOT_4:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
           {/* Ref Image: Top Blue, Bottom Green */}
           <ConcentricPip cx={26} cy={26} color={PIGMENT.BLUE} r={18} />
           <ConcentricPip cx={74} cy={26} color={PIGMENT.BLUE} r={18} />
           
           <ConcentricPip cx={26} cy={74} color={PIGMENT.GREEN} r={18} />
           <ConcentricPip cx={74} cy={74} color={PIGMENT.GREEN} r={18} />
        </svg>
      );
    case TileType.DOT_5:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
           {/* Ref Image: Corners Blue (Top) & Green (Bottom), Center Red */}
           <ConcentricPip cx={22} cy={22} color={PIGMENT.BLUE} r={14} />
           <ConcentricPip cx={78} cy={22} color={PIGMENT.BLUE} r={14} />
           
           <ConcentricPip cx={50} cy={50} color={PIGMENT.RED} r={14} />
           
           <ConcentricPip cx={22} cy={78} color={PIGMENT.GREEN} r={14} />
           <ConcentricPip cx={78} cy={78} color={PIGMENT.GREEN} r={14} />
        </svg>
      );
    case TileType.DOT_6:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
           {/* Ref Image: 2 Green Top, 4 Red Bottom. Layout: Separated Header. */}
           
           {/* Top Pair (Green): Moved up to y=21 to create a gap */}
           <ConcentricPip cx={26} cy={21} color={PIGMENT.GREEN} r={14} />
           <ConcentricPip cx={74} cy={21} color={PIGMENT.GREEN} r={14} />
           
           {/* Bottom Quad (Red): Grouped together starting at y=56 */}
           {/* Row 2 */}
           <ConcentricPip cx={26} cy={56} color={PIGMENT.RED} r={14} />
           <ConcentricPip cx={74} cy={56} color={PIGMENT.RED} r={14} />
           
           {/* Row 3 */}
           <ConcentricPip cx={26} cy={82} color={PIGMENT.RED} r={14} />
           <ConcentricPip cx={74} cy={82} color={PIGMENT.RED} r={14} />
        </svg>
      );
    
    // Characters
    case TileType.CHAR_1: return <CharText num="一" />;
    case TileType.CHAR_2: return <CharText num="二" />;
    case TileType.CHAR_3: return <CharText num="三" />;
    
    // Dragons
    case TileType.RED_DRAGON:
      return (
        <div className={`w-full h-full flex items-center justify-center ${className}`}>
          <span className="text-4xl font-black text-[#c23a30] leading-none" style={{ fontFamily: '"Noto Serif SC", serif' }}>
            中
          </span>
        </div>
      );
    case TileType.GREEN_DRAGON:
      return (
        <div className={`w-full h-full flex items-center justify-center ${className}`}>
          <span className="text-4xl font-black text-[#0f766e] leading-none" style={{ fontFamily: '"Noto Serif SC", serif' }}>
            發
          </span>
        </div>
      );
    case TileType.WHITE_DRAGON:
      return (
        <svg viewBox="0 0 100 100" className={`w-full h-full p-1 ${className}`}>
            <rect x="20" y="16" width="60" height="68" rx="4" fill="none" stroke={PIGMENT.BLUE} strokeWidth="5" />
        </svg>
      );
    default:
      return <div className="text-xs text-red-500">?</div>;
  }
};
