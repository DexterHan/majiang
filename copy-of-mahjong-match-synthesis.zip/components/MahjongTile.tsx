
import React, { useMemo } from 'react';
import { TileData } from '../types';
import { TileContent } from './TileContent';
import { motion } from 'framer-motion';

const TILE_W = 44;
const TILE_H = 60;

// --- Sub-component: Burst Effect (Clean & Crisp) ---
// A rapid expanding ring and white flash to simulate a "pop"
const BurstEffect = () => {
  return (
    <div className="absolute inset-0 pointer-events-none z-50 flex items-center justify-center">
        {/* Flash Overlay */}
        <motion.div 
            className="absolute inset-0 bg-white rounded-[10px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.8, 0] }}
            transition={{ duration: 0.2, ease: "easeOut" }}
        />
        {/* Expanding Ring */}
        <motion.div 
            className="absolute border-2 border-white rounded-full box-border"
            initial={{ width: "20%", height: "15%", opacity: 1 }}
            animate={{ width: "180%", height: "140%", opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
        />
    </div>
  );
};

interface MahjongTileProps {
  tile: TileData;
  onClick: (tile: TileData) => void;
  isInteractive?: boolean;
  isInHand?: boolean;
  isMatching?: boolean;
}

const MahjongTileComponent: React.FC<MahjongTileProps> = ({ 
  tile, 
  onClick, 
  isInteractive = true,
  isInHand = false,
  isMatching = false
}) => {
  const isBlocked = tile.isBlocked && !isInHand;
  const canClick = isInteractive && !isBlocked && !isMatching;

  // --- Style Calculations ---
  const { shadow, zIndex, x, y, initialY } = useMemo(() => {
    if (isInHand) {
      return {
        shadow: "0px 4px 6px -1px rgba(0, 0, 0, 0.3)", 
        zIndex: "auto",
        x: 0,
        y: 0,
        initialY: 0
      };
    }

    const normalizedX = tile.x; 
    let opacity = 0.6 - (normalizedX / 1500); 
    opacity = Math.max(0.3, Math.min(opacity, 0.8)); 

    const offsetX = -7; 
    const offsetY = 9; 
    const blur = 6; 
    const spread = 0; 

    const shadow = `${offsetX}px ${offsetY}px ${blur}px ${spread}px rgba(0, 0, 0, ${opacity.toFixed(3)})`;

    return {
      shadow,
      zIndex: tile.zIndex * 10,
      x: tile.x - TILE_W / 2, 
      y: tile.y - TILE_H / 2, 
      initialY: tile.y - TILE_H / 2 - 100 
    };
  }, [tile.zIndex, tile.x, tile.y, isBlocked, isInHand]);

  // --- Animation Logic ---
  const animateState = useMemo(() => {
    if (isMatching) {
        // Snappy Elimination State (Pop -> Vanish)
        return {
            scale: [1, 1.15, 0], // Quick swell then shrink to nothing
            x: isInHand ? 0 : x,
            y: isInHand ? 0 : y,
            opacity: [1, 1, 0],
            rotate: 0,
            zIndex: 100,
            filter: ["brightness(1)", "brightness(2)", "brightness(2)"], // Flash bright
            boxShadow: "0px 0px 20px 5px rgba(255, 255, 255, 0.8)", // Intense glow
            transition: { 
                duration: 0.25,
                times: [0, 0.4, 1], // Spend 40% time swelling, 60% shrinking
                ease: "easeInOut" as const
            } 
        };
    }
    // Normal State
    return {
        opacity: 1,
        scale: 1,
        rotate: isInHand ? 0 : tile.rotation,
        x: isInHand ? 0 : x,
        y: isInHand ? 0 : y,
        filter: isBlocked ? 'grayscale(0.1)' : 'none',
        boxShadow: shadow,
        zIndex: zIndex,
        transition: { 
            type: "spring" as const, 
            stiffness: 400, 
            damping: 25, 
            mass: 0.8,
            delay: (isInHand ? 0 : tile.delay) || 0 // Restored cascade delay
        }
    };
  }, [isMatching, isInHand, tile.rotation, x, y, isBlocked, shadow, zIndex, tile.delay]);

  return (
    <motion.div
      layout
      layoutId={tile.id}
      style={{
        position: isInHand ? 'relative' : 'absolute',
        left: isInHand ? 'auto' : '50%',
        top: isInHand ? 'auto' : '50%',
        touchAction: 'none',
        willChange: "transform, left, top, filter, box-shadow", 
      }}
      initial={isInHand ? false : { opacity: 0, scale: 1.1, x: x, y: initialY }}
      animate={animateState}
      // Clean Exit: Instant removal, logic handled by 'isMatching' animation mainly
      exit={{ 
          opacity: 0, 
          scale: 0, 
          transition: { duration: 0.1 } 
      }}
      variants={{
        tap: { scale: 0.95 }
      }}
      whileTap={canClick ? "tap" : undefined}
      onClick={() => canClick && onClick(tile)}
      className={`
        select-none
        rounded-[12px]
        ${isInHand ? 'w-10 h-14 sm:w-[3.2rem] sm:h-[4.2rem]' : 'w-11 h-[3.8rem] sm:w-[3.5rem] sm:h-[4.5rem]'}
        ${canClick ? 'cursor-pointer' : 'cursor-default'}
      `}
    >
      {/* Burst Effect Overlay */}
      {isMatching && <BurstEffect />}

      {/* 3D Base (Green Plastic) */}
      <div className="absolute inset-0 bg-[#153e30] rounded-[10px] transform translate-y-[6px] translate-x-[-4px] w-full h-full pointer-events-none border border-[#0a251c]"></div>
      
      {/* Middle Bone Layer */}
      <div className="absolute inset-0 bg-[#ede9d6] rounded-[10px] transform translate-y-[3px] translate-x-[-2px] w-full h-full pointer-events-none border-b border-black/10"></div>

      {/* Face Layer */}
      <div className="absolute inset-0 rounded-[10px] overflow-hidden flex items-center justify-center bg-gradient-to-br from-[#faf9f6] to-[#e6e2d6] border border-[#d4d4d4]">
         <TileContent type={tile.type} />
      </div>
    </motion.div>
  );
};

// Optimization: Custom comparator
export const MahjongTile = React.memo(MahjongTileComponent, (prev, next) => {
  if (prev.isInHand !== next.isInHand) return false;
  if (prev.isInteractive !== next.isInteractive) return false;
  if (prev.isMatching !== next.isMatching) return false; 
  
  const p = prev.tile;
  const n = next.tile;
  
  return (
      p.id === n.id &&
      p.x === n.x &&
      p.y === n.y &&
      p.zIndex === n.zIndex &&
      p.rotation === n.rotation &&
      p.isBlocked === n.isBlocked && 
      p.type === n.type &&
      p.delay === n.delay
  );
});
